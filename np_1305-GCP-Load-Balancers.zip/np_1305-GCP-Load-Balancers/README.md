
# Terraform Modules for Google Cloud Security Policies

## Overview

This repository contains Terraform modules for creating and managing Google Cloud security policies and rules. The modules are designed to help you set up a Web Application Firewall (WAF) policy to protect against OWASP Top 10 vulnerabilities


## Details

  - Area : GCP Configuration - LoadBalancer
  - NP-1305/Ingress: GCP Load Balancers must implement a Web Application Firewall (WAF) for external web applications. The WAF should utilize managed rule sets with severity levels ranging from 1 to 4. Missing rule sets are : [sqli-v33,xss-v33,lfi-v33,rfi-v33,rce-v33,methodenforcement-v33,scannerdetection-v33,protocolattack-v3,php-v33,sessionfixation-v33,java-v33,nodejs-v33,cve-,json-sqli-].



More details https://cloud.google.com/armor/docs/waf-rules




# Modules

## security_policy
This module creates a Google Cloud security policy.

## security_policy_rule
This module creates rules for the security policy, including protections against SQL Injection, Cross-Site Scripting (XSS), Local File Inclusion (LFI), Remote File Inclusion (RFI), Remote Code Execution (RCE), Method Enforcement, Scanner Detection, Protocol Attack, PHP Vulnerabilities, Session Fixation, Java Vulnerabilities, Node.js Vulnerabilities, CVEs, and JSON SQL Injection.


# Files

### main.tf

This file sets up the Google Cloud provider and uses the modules to create the security policy and rules.

### terraform.tfvars

This file defines the variable values for security policy details.

### modules/security_policy/main.tf

This file defines the `google_compute_security_policy` resource.

### modules/security_policy/variables.tf

This file defines the variables for the security policy module.

### modules/security_policy_rule/main.tf

This file defines the `google_compute_security_policy_rule` resource.

### modules/security_policy_rule/variables.tf

This file defines the variables for the security policy rule module.